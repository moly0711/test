using UnityEditor.Rendering.LookDev;
using UnityEngine;
using UnityEngine.InputSystem;

public class InputManager : MonoBehaviour
{
    private PlayerActions actions;
    private PlayerActions.GroundMovementActions groundMovement;
    [SerializeField] MoveMent movement;
    [SerializeField] MouseLook mouseLook;
    Vector2 horizontallnput; //WASD �Է½�
    Vector2 mouseInput;

    private void Awake()
    {
        actions = new PlayerActions();
        groundMovement = actions.GroundMovement;
        //GroundMovement.[action].performed += context => �Ұ�

        groundMovement.HorizontalMovement.performed += Context => horizontallnput = Context.ReadValue<Vector2>();
        groundMovement.Jump.performed += _ => movement.OnJumpPressed();//�� �Է� ���� ���ε��� Ű������  _
        groundMovement.MouseX.performed += Context => mouseInput.x = Context.ReadValue<float>();
        groundMovement.MouseY.performed += Context => mouseInput.y = Context.ReadValue<float>();
    }

    private void OnEnable()
    {
        actions.Enable();
    }

    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        movement.ReciveInput(horizontallnput);
        mouseLook.ReceiveInput(mouseInput);
    }
}
