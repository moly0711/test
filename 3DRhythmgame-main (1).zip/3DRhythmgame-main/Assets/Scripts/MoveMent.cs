using UnityEngine;

public class MoveMent : MonoBehaviour
{
    Vector2 horizontallnput;
    [SerializeField] CharacterController controller;
    [SerializeField] float speed = 11f;
    [SerializeField] float jumpForce = 5f;
    [SerializeField] float gravity = -9.81f;
    Vector3 verticalVelocity = Vector3.zero;

     LayerMask groundMask = 1 << 3; //�̰� serializedField�� ���� �� �ȵǴ��� ���� �������ִ� ������ ���� 
    bool isGrounded;

    private void Update()
    {
        // �� üũ
        
        isGrounded = Physics.Raycast(transform.position, Vector3.down, 1.2f,groundMask);

        Debug.DrawRay(transform.position, Vector3.down * 1.2f, Color.red); //Ȯ���غ�
        /*print($"groundMask: {groundMask.value}");

        if (isGrounded)
        {
            print("��");
        }*/

        if (isGrounded && verticalVelocity.y < 0)
        {
            verticalVelocity.y = -2f; // ���� �� �ణ�� �ϰ� �� �߰�
        }

        Vector3 horizontalVelocity = (transform.right * horizontallnput.x
            + transform.forward * horizontallnput.y) * speed;
        controller.Move(horizontalVelocity * Time.deltaTime);

        // �߷� ����
        verticalVelocity.y += gravity * Time.deltaTime;
        controller.Move(verticalVelocity * Time.deltaTime);




    }

    public void ReciveInput(Vector2 _horizontalInput)
    {
        horizontallnput = _horizontalInput;
    }



    public void OnJumpPressed()
    {
        if (isGrounded)
        {
            print("Jump triggered");
            verticalVelocity.y = jumpForce; // ���� �Է� �� ��� ó��
            controller.Move(verticalVelocity * Time.deltaTime);
        }
    }
}
