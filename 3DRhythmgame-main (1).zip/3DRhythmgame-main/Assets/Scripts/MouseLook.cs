using UnityEngine;

public class MouseLook : MonoBehaviour
{

    [SerializeField] float sensitivityX = 9f;
    [SerializeField] float sensitivityY = 0.5f;
    float mouseX, mouseY;
    // Start is called once before the first execution of Update after the MonoBehaviour is created

    [SerializeField] Transform PlayerCam;
    [SerializeField] float xClamp = 85f; //�Ӹ����� �ڵ��� ����
    float xRotation = 0f;
    public void Update()
    {
        transform.Rotate(Vector3.up, mouseX * Time.deltaTime);
        xRotation -= mouseY; //�������� ����
        xRotation = Mathf.Clamp(xRotation, -xClamp, xClamp);
        Vector3 targetRotation = transform.eulerAngles;
        targetRotation.x = xRotation;
        PlayerCam.eulerAngles = targetRotation;
    }
    public void ReceiveInput(Vector2 mouseInput)
    {
        mouseX = mouseInput.x *sensitivityX;
        mouseY = mouseInput.y *sensitivityY;
    }
}
